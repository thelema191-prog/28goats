def send_sms(*a,**k): return True

def send_email(*a,**k): return True
